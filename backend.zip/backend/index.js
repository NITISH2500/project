const express=require('express');
const app= express();
const mongoose=require('mongoose');
const path=require('path');
const signUp=require('./schema');
mongoose.connect('mongodb://localhost:27017/signsUp', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("MONGO CONNECTION OPEN!!!")
    })
    .catch(err => {
        console.log("OH NO MONGO CONNECTION ERROR!!!!")
        console.log(err)
    })
    app.use(express.urlencoded({ extended: true }));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.get('/api',(req,res)=>{
    console.log("working");
   res.render('proj.ejs');
})
app.post('/products', async (req, res) => {
    const newProduct = new signUp(req.body);
    console.log(newProduct);
    await newProduct.save();
    
    res.redirect(`/api`);
 
})
app.listen(3000, () => {
    console.log("APP IS LISTENING ON PORT 3000!")
})

