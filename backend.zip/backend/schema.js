const mongoose = require('mongoose');

const signSchema= new mongoose.Schema({
    firstname:{
        type:String,
        
    },
    lastname:{
        type:String,
       
    },
    email:{
        type:String,
        
    },

    Password:{

        type:String,
        

    },
    education: {
        schooling:{
            
            type:String,
        },
        universityorinstitutionname:{
            type:String,
        } 

    },
    skillsAndEndorcement: {
        type:String,
    },

    Accomplishments: {
        courses:{
            type:String,
        },

        languages:{
            type:String,

        }
    }
    
})

const signUp =mongoose.model('sign',signSchema);
module.exports=signUp;